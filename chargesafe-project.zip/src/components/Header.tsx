import React from 'react';
import { Lang, TRANSLATIONS } from '../utils/translations';
import { UserRole } from '../types';
import { Zap, Wifi, WifiOff, Globe, Shield, Smartphone, User, UserCheck } from 'lucide-react';

interface HeaderProps {
  lang: Lang;
  onToggleLang: () => void;
  activeRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  isCloudLive: boolean;
  totalSlots: number;
  occupiedSlots: number;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onOpenLogin: () => void;
  userEmail?: string;
  isSuperAdmin?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  activeRole,
  isCloudLive,
  totalSlots,
  occupiedSlots,
  activeTab,
  onSelectTab,
  onOpenLogin,
  userEmail,
  isSuperAdmin,
}) => {
  const t = TRANSLATIONS[lang];
  const freeSlots = totalSlots - occupiedSlots;

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40 shadow-md">
      {/* Top Banner with Connectivity & Station Info */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs border-b border-slate-800/60">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-medium">
            {isCloudLive ? (
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <Wifi className="w-3.5 h-3.5" />
                <span>{t.cloudLive}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-amber-400">
                <WifiOff className="w-3.5 h-3.5" />
                <span>{t.cloudOffline}</span>
              </span>
            )}
          </div>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <div className="hidden sm:flex items-center gap-2 text-slate-400">
            <span>{totalSlots} Slots (100 Boxes × 8 Sockets)</span>
            <span>·</span>
            <span className="text-emerald-400 font-medium">{freeSlots} {t.slotFree}</span>
            <span>·</span>
            <span className="text-amber-400 font-medium">{occupiedSlots} {t.slotOccupied}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Language Toggle Button */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition border border-slate-700"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span>{t.langToggle}</span>
          </button>

          {/* Role Indicator / Switcher */}
          <button
            onClick={onOpenLogin}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold transition ${
              isSuperAdmin || activeRole === 'admin'
                ? 'bg-gradient-to-r from-purple-900 to-indigo-900 text-amber-300 border border-amber-400/40 shadow-sm hover:brightness-110'
                : activeRole === 'staff'
                ? 'bg-blue-900/60 text-blue-200 border border-blue-700 hover:bg-blue-800/80'
                : 'bg-emerald-900/60 text-emerald-200 border border-emerald-700 hover:bg-emerald-800/80'
            }`}
          >
            {isSuperAdmin || activeRole === 'admin' ? (
              <>
                <span className="text-amber-400 font-bold">👑 Total Control:</span>
                <span className="font-mono text-[11px] truncate max-w-[140px] sm:max-w-none text-white">
                  {userEmail || 'afworld208@gmail.com'}
                </span>
              </>
            ) : (
              <>
                {activeRole === 'staff' && <UserCheck className="w-3.5 h-3.5" />}
                {activeRole === 'customer' && <User className="w-3.5 h-3.5" />}
                <span className="capitalize">{activeRole}</span>
              </>
            )}
            <span className="text-slate-400 text-[10px]">▼</span>
          </button>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 shadow-md">
            <Zap className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white">{t.appName}</h1>
              <span className="text-[10px] tracking-wider uppercase font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                PRO 800
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">{t.subTitle}</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 bg-slate-800/90 p-1 rounded-xl border border-slate-700/80 overflow-x-auto text-xs">
          <button
            onClick={() => onSelectTab('customer')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'customer'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{t.navCustomer}</span>
          </button>

          <button
            onClick={() => onSelectTab('staff')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'staff'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>{t.navStaff}</span>
          </button>

          <button
            onClick={() => onSelectTab('slots')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'slots'
                ? 'bg-slate-700 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{t.navSlots}</span>
          </button>

          <button
            onClick={() => onSelectTab('admin')}
            className={`px-3 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'admin'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>{t.navAdmin}</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
