import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

import { getAuth, GoogleAuthProvider } from 'firebase/auth';

// Initialize Firebase App
export const app = initializeApp(firebaseConfig);

// Initialize Firebase Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export const SUPER_ADMIN_EMAIL = 'afworld208@gmail.com';
export const SUPER_ADMIN_EMAILS = ['afworld208@gmail.com', 'raihanathrai55@gmail.com'];
export const isSuperAdminEmail = (email?: string): boolean =>
  !!email && SUPER_ADMIN_EMAILS.some(e => e.toLowerCase() === email.toLowerCase());

// Initialize Firestore with configured databaseId (if specified) or default
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Test connection on boot as required by Firebase skill
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('Firebase Firestore connection verified.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline. Checking fallback sync.');
      return false;
    }
    // Expected if test doc does not exist, but connection was made to server
    return true;
  }
}

testFirestoreConnection().catch((err) => {
  console.warn('Firebase init test notice:', err);
});
