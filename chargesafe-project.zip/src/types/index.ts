export type DepositStatus = 'CHARGING' | 'COLLECTED';

export type CableType = 'Type-C' | 'Lightning (iPhone)' | 'Micro-USB' | 'Own Cable' | 'Other';

export interface DepositRecord {
  token: number; // 1 to 10000
  tokenStr: string; // "00001" to "10000"
  mobile: string; // 10 digit number
  box: string; // "B001" to "B100"
  socket: string; // "S01" to "S08"
  slotKey: string; // "B001-S01"
  status: DepositStatus;
  time: string; // ISO string
  formattedTime: string;
  collectedAt?: string;
  collectedBy?: string;
  photo?: string; // base64 data URI
  phoneModel?: string;
  cableType?: CableType;
  notes?: string;
  fee?: number; // optional fee if charging applied
}

export interface Slot {
  box: string;
  socket: string;
  key: string; // "B001-S01"
  boxNum: number;
  socketNum: number;
}

export type UserRole = 'customer' | 'staff' | 'admin';

export interface UserSession {
  role: UserRole;
  username?: string;
  displayName?: string;
  id?: string;
  email?: string;
  isSuperAdmin?: boolean;
}

export interface StationSettings {
  ownerEmail: string;
  emergencyLockdown: boolean;
  emailAlertsEnabled: boolean;
  staffPassword?: string;
  pricingPerHour?: number;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  action: 'DEPOSIT' | 'COLLECT' | 'LOGIN' | 'LOGOUT' | 'BACKUP_EXPORT' | 'BACKUP_IMPORT' | 'VACATE_SLOT' | 'SYSTEM_RESET' | 'SYSTEM_START';
  performedBy: string;
  details: string;
  token?: number;
  slotKey?: string;
}

export type Language = 'en' | 'ml';
